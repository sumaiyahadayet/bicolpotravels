<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/js/html-table.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
    function ChangeStatus(student_id, output_id, status) {


        $.ajax({
            url: '/admin/student/update-status',
            type: 'GET',
            data: {
                student_id: student_id,
            },
            success: function(response) {

                if (response == 'Active') {


                    document.getElementById(output_id).innerHTML = 'Active';
                    document.getElementById(output_id).className = "kt-badge--inline kt-badge--pill kt-badge  kt-badge--primary";


                } else {


                    document.getElementById(output_id).innerHTML = 'Inactive';
                    document.getElementById(output_id).className = "kt-badge--inline kt-badge--pill kt-badge  kt-badge--danger";


                }



            }
        });

    }
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content-head'); ?>

<!-- begin:: Content Head -->
<div class="kt-subheader   kt-grid__item d-print-none" id="kt_subheader">
    <div class="kt-subheader__main">
        <h3 class="kt-subheader__title">Our Team</h3>

        <span class="kt-subheader__separator kt-subheader__separator--v"></span>



    </div>

</div>
<!-- end:: Content Head -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="d-print-none" id="snackbar">

    <div class="alert kt-padding-l-30 kt-padding-r-30 kt-padding-0 alert-<?php if(isset($alert)&&$alert!=''): ?><?php echo e($alert_type); ?><?php endif; ?>" role="alert">
    <div class="alert-icon"><i class="flaticon-warning"></i></div>
    <div class="alert-text">
        <?php if(isset($alert)&&$alert!=''): ?><?php echo e($alert); ?>

        <?php endif; ?></div>
    </div>

</div>

<div class="kt-portlet kt-portlet--mobile">
    <div class="kt-portlet__head kt-portlet__head--lg d-print-none" style="
    float: right;
    display: inline-block;
    align-items: center;
    margin-top: 10px;
">

        <div class="kt-portlet__head-toolbar" style="
        float: right;
        display: inline-block;
        align-items: center;
        margin-top: 10px;
    ">
            <div class="kt-portlet__head-wrapper">
                <div class="kt-portlet__head-actions">

                    <div class="dropdown dropdown-inline">
                        <a href="<?php echo e(route('add-team')); ?>" class="btn btn-success btn-icon-sm ">
                            <i class="la la-plus"></i>
                            New Data
                        </a>
                    </div>

                    &nbsp;




                </div>
            </div>
        </div>
    </div>

    <div class="kt-portlet__body d-print-none">
        <div class="kt-form kt-form--label-right kt-margin-t-20 kt-margin-b-10">
            <div class="row align-items-center">
                <div class="col-xl-8 order-2 order-xl-1">
                    <div class="row align-items-center">
                        <div class="col-md-4 kt-margin-b-20-tablet-and-mobile">

                        </div>

                    </div>
                </div>
                <div class="col-xl-4 order-1 order-xl-2 kt-align-right">

                </div>
            </div>
        </div>
    </div>
    <div class="kt-portlet__body kt-portlet__body--fit">
        <!--begin: Datatable -->
        <table class="kt-datatable" id="html_table" width="100%">
            <thead>
                <tr>
                    <th title="Field #1">Serial</th>

                    <th title="Field #5" class="kt-datatable__cell kt-datatable__cell--sort">Image</th>
                    <th title="Field #3">Name</th>
                    <th title="Field #4">Job</th>
                    <th class="kt-datatable__cell kt-datatable__cell--sort kt-datatable__cell--sorted" data-sort="asc"  title="Field #2">Order</th>
                    <th  title="Field #8">Actions</th>
                    <th title="Field #5">Created At</th>
                </tr>
            </thead>
            <tbody>
              <?php
                $serial=0;
              ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $serial++;
                  ?>
                <tr>

                    <td><?php echo e($serial); ?></td>

                    <td>
                        <img src="<?php echo e(asset($team->image)); ?>" style="height:80px;width:auto" alt="">
                    </td>
                    <td><?php echo e($team->name); ?></td>
                    <td><?php echo e($team->job); ?></td>
                    <td><?php echo e($team->order); ?></td>
                    <td>
                     <a href="/admin/edit-team/<?php echo e($team->id); ?>" class="edit"><i class="la la-edit" data-toggle="tooltip" title="Edit"></i></a>
                     <a href="/admin/delete-team/<?php echo e($team->id); ?>" class="delete"> <i class="la la-trash" data-toggle="tooltip" title="Delete"></i> </a>
                    </td>
                    <td><?php echo e($team->created_at); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <!--end: Datatable -->
    </div>
</div>
<?php $__env->stopSection(); ?>


 <?php $__env->startSection('modals'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views/admin/team/index.blade.php ENDPATH**/ ?>