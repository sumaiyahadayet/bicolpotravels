<?php $__env->startSection('content'); ?>

<div class="container" style="margin-left: 300px; margin-top:200px; margin-bottom:200px; display:block;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">


                <div class="card-body text-center">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="flex-1 text-center">
                   <?php if(auth()->guard()->guest()): ?>
                       <a class="no-underline hover:underline text-gray-300 text-sm p-3" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                       <?php if(Route::has('register')): ?>
                           <a class="no-underline hover:underline text-gray-300 text-sm p-3" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                       <?php endif; ?>
                   <?php else: ?>
                       <span class="text-gray-300 text-sm pr-4"><?php echo e(Auth::user()->name); ?></span>

                       <a href="<?php echo e(route('logout')); ?>"
                          class="no-underline hover:underline text-gray-300 text-sm p-3"
                          onclick="event.preventDefault();
                               document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                       <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                           <?php echo e(csrf_field()); ?>

                       </form>
                   <?php endif; ?>
               </div>
<?php $__env->stopSection(); ?>

<!-- Global site tag (gtag.js) - Google Analytics -->


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views/home.blade.php ENDPATH**/ ?>