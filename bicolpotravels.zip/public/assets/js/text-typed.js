$(document).ready(function ($) {
    'use strict';
 
/* ---------------------------------------------
Typed text
 --------------------------------------------- */

    var typed = new Typed('#typed', {
        stringsElement: '#typed-strings',
        typeSpeed: 60,
        backSpeed: 30,
        startDelay: 1000,
        loop: true,
        loopCount: Infinity
    });
     });

 
 