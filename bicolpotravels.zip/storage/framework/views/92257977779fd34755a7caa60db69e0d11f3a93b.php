<!--begin::Fonts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/webfont/1.6.16/webfontloader.js"></script>
<script>
     WebFont.load({
          google: {
               "families": ["Poppins:300,400,500,600,700", "Roboto:300,400,500,600,700"]
          },
          active: function() {
               sessionStorage.fonts = true;
          }
     });
</script>
<!--end::Fonts -->
<?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views/admin/layouts/assets/font.blade.php ENDPATH**/ ?>