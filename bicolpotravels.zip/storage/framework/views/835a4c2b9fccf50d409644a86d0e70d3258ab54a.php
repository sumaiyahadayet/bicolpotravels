<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="" />
<meta name="keywords" content="">
<meta name="author" content="" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views/admin/layouts/header/meta.blade.php ENDPATH**/ ?>