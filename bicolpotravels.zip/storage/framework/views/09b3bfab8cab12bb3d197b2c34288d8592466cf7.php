


<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content-head'); ?>

<?php echo $__env->make('admin.layouts.header.content-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!--Begin::Section-->
<div class="row">

</div>
<!--End::Section-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views//admin/dashboard/index.blade.php ENDPATH**/ ?>