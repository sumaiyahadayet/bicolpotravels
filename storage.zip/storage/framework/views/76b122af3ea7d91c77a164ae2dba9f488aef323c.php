


<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content-head'); ?>

<?php echo $__env->make('admin.layouts.header.content-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!--Begin::Section-->
<div class="row">
     <div class="kt-portlet kt-portlet--mobile" style="justify-content:center;">
          <div class="kt-portlet__head">
               <div class="kt-portlet__head-label">
                    <h3 class="kt-portlet__head-title">
                    Monitor your site visitors
                    </h3>
               </div>
          </div>
          <div class="kt-portlet__body">
               <a href="https://analytics.google.com/analytics/web/#/realtime/rt-overview/a173945284w241416827p225186525/"><button type="button" class="btn btn-outline-primary">Visit</button></a>
     </div>

</div>
</div>
<div class="row">
     <div class="col-md-12">
<div class="alert alert-info" role="alert">
   <div class="alert-text">Maintain recommended image size for better view</div>
</div></div>
</div>
<div class="col-md-6" style="margin:0px auto; display:block;">
 <img class="" src="<?php echo e(asset('/assets/images/admin.jpg')); ?>" alt="Card image" style="height:auto;width:100%; ">
</div>
<!--End::Section-->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>