<?php $__env->startSection('content-head'); ?>
     <!-- begin:: Content Head -->
     <div class="kt-subheader   kt-grid__item d-print-none" id="kt_subheader">
     <div class="kt-subheader__main">
         <h3 class="kt-subheader__title">Dashboard</h3>

         <span class="kt-subheader__separator kt-subheader__separator--v"></span>



         <div class="kt-input-icon kt-input-icon--right kt-subheader__search kt-hidden">
            <input type="text" class="form-control" placeholder="Search order...">
            <span class="kt-input-icon__icon kt-input-icon__icon--right">
                          <span><i class="flaticon2-search-1"></i></span>
            </span>
         </div>
     </div>
     
     </div>
     <!-- end:: Content Head -->
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views/admin/layouts/header/content-head.blade.php ENDPATH**/ ?>