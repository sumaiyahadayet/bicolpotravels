<!DOCTYPE html>

<html lang="en">
<!-- begin::Head -->

<head>

     <title>Bicolpo Travels | Admin</title>
 <link rel="icon" href="<?php echo e(asset('assets/images/title-logo.png')); ?>" type="image/icon">
    
    <?php echo $__env->yieldContent('meta'); ?>


    <!-- Favicon icon -->
    <link rel="shortcut icon" href="" type="image/x-icon">


    <?php echo $__env->make('admin.layouts.assets.font', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->make('admin.layouts.assets.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!-- end::Head -->

<!-- begin::Body -->

<!-- begin::Body -->
<body  class="kt-header--fixed kt-header-mobile--fixed kt-subheader--fixed kt-subheader--enabled kt-subheader--solid kt-aside--enabled kt-aside--fixed kt-page--loading"  >


<!-- begin:: Page -->
<!-- begin:: Header Mobile -->
<div id="kt_header_mobile" class="kt-header-mobile  kt-header-mobile--fixed " >
<div class="kt-header-mobile__logo">
      <a href="<?php echo e(route('dashboard')); ?>">

      </a>
</div>
<div class="kt-header-mobile__toolbar">
      <button class="kt-header-mobile__toggler kt-header-mobile__toggler--left" id="kt_aside_mobile_toggler"><span></span></button>

      <button class="kt-header-mobile__toggler" id="kt_header_mobile_toggler"><span></span></button>
      <button class="kt-header-mobile__topbar-toggler" id="kt_header_mobile_topbar_toggler"><i class="flaticon-more"></i></button>
</div>
</div>
<!-- end:: Header Mobile -->
<div class="kt-grid kt-grid--hor kt-grid--root">
      <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">

     <?php echo $__env->make('admin.layouts.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

           <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">
               <?php echo $__env->make('admin.layouts.header.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor">


<?php echo $__env->yieldContent('content-head'); ?>


<!-- begin:: Content -->
<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
<!--Begin::Dashboard 1-->



     <?php echo $__env->yieldContent('content'); ?>


<!--End::Dashboard 1-->
</div>
<!-- end:: Content -->
</div>

<!-- begin:: Footer -->
<div class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop d-print-none">
<div class="kt-footer__copyright">
      2020&nbsp;&copy;&nbsp;<a href="https://bicolpotravels.com" target="_blank" class="kt-link">Bicolpo Travels</a>
</div>

</div>
<!-- end:: Footer -->
</div>
</div>
</div>

<!-- end:: Page -->






<?php echo $__env->make('admin.layouts.sidebar.sticky-toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('modals'); ?>

<?php echo $__env->make('admin.layouts.assets.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('js'); ?>

<script type="text/javascript">

setInterval(
     function(){


          $.ajax({
             url: '/admin/payment/update-due-payments',
             type: 'GET',
             data: {

             },
             success: function(response) {

                     // alert(response);

             }
         });


    }, 3600000);



<?php if($errors->any()): ?>

    ShortToast('','<?php echo e($errors->first('message')); ?>', '<?php echo e($errors->first('type')); ?>')

<?php endif; ?>


</script>

</body>
<!-- end::Body -->

</html>
<?php /**PATH C:\xampp\htdocs\bicolpotravels\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>